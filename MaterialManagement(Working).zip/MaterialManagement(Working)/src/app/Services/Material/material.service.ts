import { Injectable } from '@angular/core';
import { IMaterialNode } from '../../Models/Interfaces/material-node';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MaterialService{
  private materialClassesUrl: string = "http://localhost:63734/api/Materials/Values/MaterialClasses"
  private materialDefinitionsUrl: string = "http://localhost:63734/api/Materials/Values/MaterialDefinitions"
  constructor(private http: HttpClient) { }
   _getMaterialClasses(): Observable<string[]>   {  
    //  return [new MaterialNode("Milk", [new MaterialNode("FatContent", [], "exe")],"")];
    return this.http.get<string[]>(this.materialClassesUrl);
  }
  _getMaterialDefinitions(materialClass: IMaterialNode): Observable<string[]>
  {
    // return this.http.get<string[]>(this.materialDefinitionsUrl,{params{materialClass.Name}}  );
    
const params = new HttpParams()
.set('materialClassName', materialClass.Name);
    return this.http.get<string[]>(this.materialDefinitionsUrl, {params});
 
  }
}
