export interface IProperty {
    name: string;
    value : Float32Array;
}
