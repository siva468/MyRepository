import { IMaterialNode } from '../Interfaces/material-node';

export class MaterialDefinition implements IMaterialNode {
    public constructor(name1: string) 
  {
      this.Name = name1;
  }
    Name: string;    
    Properties: IMaterialNode[];
}
