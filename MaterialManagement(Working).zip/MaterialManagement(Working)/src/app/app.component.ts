
import { Component } from '@angular/core';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { BehaviorSubject, observable, Observable } from 'rxjs';
import {map} from 'rxjs/operators';
import { MatTabLink } from '@angular/material';
import {NestedTreeControl} from '@angular/cdk/tree';
import { MaterialService } from './Services/Material/material.service';
import { IMaterialNode } from './Models/Interfaces/material-node';
import { MaterialClass } from './Models/MaterialClass/material-class';
import { MaterialDefinition } from './Models/MaterialDefinition/material-definition';
import { of } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'MaterialManagement';
  dataFromServer: IMaterialNode[];
  nestedDataSource: MatTreeNestedDataSource<IMaterialNode>;
  
  private _getChildren(node: IMaterialNode)
   {
     var materialClass = node as MaterialClass;
     if(materialClass != null)
     {
        return of(materialClass.MaterialDefinitions);
        //return materialClass.Properties.concat(materialClass.MaterialDefinitions);
     }
     var materialDefinition = node as MaterialDefinition;
     if(materialDefinition != null)
     {
       return of(materialDefinition.Properties);
     }
     return new Array();
   };
  nestedTreeControl : NestedTreeControl<IMaterialNode> = new NestedTreeControl<IMaterialNode>(this._getChildren);
  _materialService : MaterialService;
  
  constructor(materialService: MaterialService){
    this.nestedDataSource = new MatTreeNestedDataSource();
    this._materialService = materialService;
    materialService._getMaterialClasses().subscribe(
      data => this.AssignMat(data),
      (err:any) => console.log(err),
      ()=>console.log("Reading Completed")
    );
  }
  private hasNestedChild(_: number, nodeData: IMaterialNode)
  {
    // if(nodeData.Children == undefined)
    // {
    //   return false;
    // }
    // return nodeData.Children.length > 0;
    return true;
  }
  private AssignMat( matClassNames : string[])
  {
      let materialClassNodes : IMaterialNode[] = [];
      for(var i=0; i<matClassNames.length; i++)
      {
        materialClassNodes.push( new MaterialClass(this._materialService, matClassNames[i]))
      }
      
      this.dataFromServer =  materialClassNodes;
      this.nestedDataSource.data = this.dataFromServer;
  }
  public OnExpandClick(event: any, node: IMaterialNode)
  {
      let materialDefinitionNames : string[];
      const foundNode = this.nestedDataSource.data.find(_node => _node == node);
      var materialClass = foundNode as MaterialClass;
      if(materialClass != null)
      {
        materialClass.loadMaterialDefinitions();
        this.nestedDataSource.data = null;
        this.nestedDataSource.data = this.dataFromServer;
      }
      // this._materialService._getMaterialDefinitions(foundNode).pipe(map(data => {materialDefinitionNames = data}));//.subscribe(data => materialDefinitionNames = data));
      
      // let materialDefinitionNodes : IMaterialNode[] = new Array();
      // for(var i=0; i<materialDefinitionNames.length; i++)
      // {
      //   materialDefinitionNodes.push(new MaterialNode(materialDefinitionNames[i], null))
      // }
      // foundNode.Children.concat(materialDefinitionNodes);
      // this.nestedDataSource.data = null;
      // this.nestedDataSource.data = this.dataFromServer;
      console.log("Expand Clicked");
  }
}
0