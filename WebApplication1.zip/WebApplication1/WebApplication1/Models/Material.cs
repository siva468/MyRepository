﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Material
    {
        public Material(string name)
        {
            this.name = name;
            this.children = new List<Material>();
        }
        public string name
        {
            get;
            set;
        }
        public List<Material> children
        {
            get;
            set;
        }
        public void AddChild(Material material)
        {
            children.Add(material);
        }
    }
}