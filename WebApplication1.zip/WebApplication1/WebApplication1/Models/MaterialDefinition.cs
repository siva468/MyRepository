﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class MaterialDefinition
    {
        private List<MaterialProperty> properties;
        #region constructor
        public MaterialDefinition(string name)
        {
            properties = new List<MaterialProperty>();
            Name = name;
            Code = name;
        }
        #endregion
        #region properties
        public string Name
        {
            get; set;
        }
        public string Code
        {
            get; set;
        }
        public List<MaterialProperty> Properties
        {
            get { return properties; }
        }
        #endregion
        #region methods
        public void AddProperty(MaterialProperty property)
        {
            properties.Add(property);
        }
        #endregion
    }
}