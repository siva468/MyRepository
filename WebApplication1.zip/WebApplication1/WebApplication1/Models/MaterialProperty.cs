﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class MaterialProperty
    {
        private double m_value;
        private string m_PropDefinitionId;
        #region constructor
        public MaterialProperty(string propDefintionId, double value)
        {
            m_PropDefinitionId = propDefintionId;
            m_value = value;
        }
        #endregion
    }
}