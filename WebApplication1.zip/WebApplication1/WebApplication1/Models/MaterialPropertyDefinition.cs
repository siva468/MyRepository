﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class MaterialPropertyDefinition
    {
        private string m_Name;
        private string m_Code;
        private float m_DefaultValue;
        #region constructor
        public MaterialPropertyDefinition(string name, string code, float defaultValue)
        {
            m_Name = name;
            m_Code = code;
            m_DefaultValue = defaultValue;
        }
        #endregion
    }
}