﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class MaterialClass
    {
        private string m_Name;
        private string m_Code;
        private List<MaterialProperty> properties;
        private List<MaterialDefinition> materialDefinitions;
        #region constructor
        public MaterialClass(string name, string code)
        {
            m_Name = name;
            m_Code = code;
            properties = new List<MaterialProperty>();
            materialDefinitions = new List<MaterialDefinition>();
        }
        #endregion
        #region properties
        public string Name
        {
            get { return m_Name; }
        }
        public string Code
        {
            get { return m_Code; }
        }
        public IEnumerable<MaterialDefinition> MaterialDefinitions
        {
            get { return materialDefinitions; } 
        }
        public List<MaterialProperty> Properties
        {
            get { return properties; }
        }
        #endregion
        #region methods
        public void AddProperty(MaterialProperty property)
        {
            properties.Add(property);
        }
        public void AddMaterialDefinitions(MaterialDefinition materialDefinition)
        {
            materialDefinitions.Add(materialDefinition);
        }
        #endregion
    }
}