﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class MaterialsController : ApiController
    {
        private List<MaterialClass> materialClasses;
        public MaterialsController()
        {
            MaterialDefinition water = new MaterialDefinition("water");
            MaterialDefinition sugar = new MaterialDefinition("Sugar");
            MaterialDefinition dietCoke = new MaterialDefinition("DietCoke");
            MaterialDefinition coke = new MaterialDefinition("Coke");
            MaterialPropertyDefinition pH = new MaterialPropertyDefinition("pH", "pH", 7);
            MaterialPropertyDefinition density = new MaterialPropertyDefinition("density", "density", 25);
            materialClasses = new List<MaterialClass>();

            MaterialClass rawMaterial = new MaterialClass("Raw Material", "RawMaterial");
            rawMaterial.AddMaterialDefinitions(water);
            rawMaterial.AddMaterialDefinitions(sugar);
            rawMaterial.AddProperty(new MaterialProperty("pH", 4));
            water.AddProperty(new MaterialProperty("pH", 7.2));

            MaterialClass outputMaterial = new MaterialClass("Output Material", "OutputMaterial");
            outputMaterial.AddMaterialDefinitions(dietCoke);
            outputMaterial.AddMaterialDefinitions(coke);
            outputMaterial.AddProperty(new MaterialProperty("density", 43));
            dietCoke.AddProperty(new MaterialProperty("pH", 5));

            materialClasses.Add(rawMaterial);
            materialClasses.Add(outputMaterial);
        }
        [Route("api/Materials/Values/MaterialClasses")]
        [HttpGet]
        public IHttpActionResult GetMaterialClasses()
        {
            //Material material1 = new Material("Fat Content");
            //Material material2 = new Material("Milk");
            //material2.AddChild(material1);

            //Material material3 = new Material("pH");
            //Material material4 = new Material("Water");
            //material4.AddChild(material3);
            //List<Material> data = new List<Material>();
            //data.Add(material2);
            //data.Add(material4);
            //return Ok(data);

            return Ok(materialClasses.Select(item => item.Name));

        }
        [Route("api/Materials/Values/MaterialDefinitions")]
        [HttpGet]
        public IHttpActionResult GetMaterialDefinitions(string materialClassName)
        {
            //Material material1 = new Material("Fat Content");
            //Material material2 = new Material("Milk");
            //material2.AddChild(material1);

            //Material material3 = new Material("pH");
            //Material material4 = new Material("Water");
            //material4.AddChild(material3);
            //List<Material> data = new List<Material>();
            //data.Add(material2);
            //data.Add(material4);
            //return Ok(data);
            var materialClass = materialClasses.Find(item => item.Name == materialClassName);
            return Ok(materialClass.MaterialDefinitions.Select(item => item.Name));

        }
    }
}