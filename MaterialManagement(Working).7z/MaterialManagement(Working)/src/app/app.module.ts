import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import {CdkTreeModule} from '@angular/cdk/tree';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatIconModule, MatButtonModule} from '@angular/material'; 
import {MatTreeModule} from '@angular/material/tree';
import { MaterialService } from './Services/Material/material.service';
import { HttpClientModule} from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatTreeModule,
    MatIconModule,
    MatButtonModule,
    BrowserAnimationsModule,
    CdkTreeModule,
    HttpClientModule
  ],
  providers: [MaterialService],
  bootstrap: [AppComponent]
})
export class AppModule { }
