import { IMaterialNode } from '../Interfaces/material-node';
import { MaterialService } from 'src/app/Services/Material/material.service';
import { MaterialDefinition } from '../MaterialDefinition/material-definition';

export class MaterialClass implements IMaterialNode
{
    public constructor( private _materialService: MaterialService, name1: string) 
    {
      this.Name = name1;
    }
    Name: string;    
    Properties: IMaterialNode[] = [];
    MaterialDefinitions: IMaterialNode[] = [];
    public loadMaterialDefinitions()
    {
        if(this.MaterialDefinitions.length > 0)
        {
            return;
        }
        let materialDefinitionNames : string[];
        this._materialService._getMaterialDefinitions(this).subscribe(data => data.forEach(element => {this.MaterialDefinitions.push(new MaterialDefinition(element))})); 
    }
}
