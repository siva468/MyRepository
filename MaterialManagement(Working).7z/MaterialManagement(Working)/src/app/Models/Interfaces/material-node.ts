
export interface IMaterialNode {

  
  Name: string;
  Properties: IMaterialNode[];
}

