import { IProperty } from '../Interfaces/iproperty';

export class Property implements IProperty
{
    name: string;   
    value: Float32Array;
}
